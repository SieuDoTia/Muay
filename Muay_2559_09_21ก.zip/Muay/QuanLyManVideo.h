//
//  QuanLyManVideo.h
//  Muay
//
//  Created by 小小 on 7/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuanLyManVideo : UIViewController {
   
//   NSInteger soBoTap;    // số bộ tập
//   NSInteger soBaiHoc;   // số bài học
}

- (void)chieuVideoChoBoTap:(NSInteger)soBoTap vaSoBaiHoc:(NSInteger)soBaiHoc;
//@property (readwrite) NSInteger soBoTap;
//@property (readwrite) NSInteger soBaiHoc;

@end

//
//  main.m
//  Muay
//
//  Created by 小小 on 7/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
   }
}

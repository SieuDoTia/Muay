//
//  QuanLyDanhSachBaiHoc.h
//  Muay
//
//  Created by 小小 on 10/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuanLyDanhSachBaiHoc : UITableViewController {
   
   NSInteger soBoTap;  // cho biết cần chiếu số bộ tập nào
   NSInteger soBaiHoc;  // cho biết cần chiếu số bài học nào
}

@property (readwrite) NSInteger soBoTap;
@property (readwrite) NSInteger soBaiHoc;

@end

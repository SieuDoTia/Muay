//
//  TeBaoDanhSachBaiHoc.h
//  Muay
//
//  Created by 小小 on 10/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeBaoDanhSachBaiHoc : UITableViewCell {

   IBOutlet UIImageView *anh;
   IBOutlet UILabel *vanBan;
}

@property (readwrite) UIImageView *anh;
@property (readwrite) UILabel *vanBan;

@end

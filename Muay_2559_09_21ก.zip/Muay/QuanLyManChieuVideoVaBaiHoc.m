//
//  QuanLyManChieuVideoVaBaiHoc.m
//  Muay
//
//  Created by 小小 on 21/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "QuanLyManChieuVideoVaBaiHoc.h"
#import "QuanLyManVideo.h"
#import "QuanLyDanhSachBaiHoc.h"


@interface QuanLyManChieuVideoVaBaiHoc ()

@end

@implementation QuanLyManChieuVideoVaBaiHoc

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
   quanLyManVideo = [[QuanLyManVideo alloc] initWithNibName:@"ManChieuVideo-iPhone" bundle:[NSBundle mainBundle]];
//   NSLog( @"quanLyManVideo.view %x", quanLyManVideo.view );

   [self addChildViewController:quanLyManVideo];
   [self.view addSubview:quanLyManVideo.view];

//   [quan.view setFrame:<SOME_FRAME>];
   [quanLyManVideo didMoveToParentViewController:self];
   
   quanLyDanhSachBaiHoc = [[QuanLyDanhSachBaiHoc alloc] initWithNibName:@"DanhSachBaiHoc-iPhone" bundle:[NSBundle mainBundle]];
   
   [self addChildViewController:quanLyDanhSachBaiHoc];
   [self.view addSubview:quanLyDanhSachBaiHoc.view];
//   [anotherVC.view setFrame:<ANOTHER_FRAME>];
   [quanLyDanhSachBaiHoc didMoveToParentViewController:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  QuanLyDanhSachBaiHoc.m
//  Muay
//
//  Created by 小小 on 10/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "QuanLyDanhSachBaiHoc.h"
#import "TeBaoDanhSachBaiHoc.h"

#import "QuanLyBoTap.h"

@interface QuanLyDanhSachBaiHoc ()

@end

@implementation QuanLyDanhSachBaiHoc

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated; {
   
   CGRect khungManBan = CGRectMake(0.0f, 220.0f, 320.0f, 320.0f);
   
   [UIView animateWithDuration:0.25f animations:^{

      self.tableView.frame = khungManBan;
      
      // if you have other controls that should be resized/moved to accommodate
      // the resized tableview, do that here, too
   }];
   
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//   quanLyManVideo = [[QuanLyManVideo alloc] init];
   

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
   UINib *nib = [UINib nibWithNibName:@"TeBaoBaiHoc" bundle:[NSBundle mainBundle]];
   [self.tableView registerNib:nib forCellReuseIdentifier:@"BàiHọc"];
   
   [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(laySoBoTap:) name:@"星凤CóSốBộTập" object:NULL];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView; {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
   if( soBoTap == 3 )
      return 3;
   else
      return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section; {

    // Return the number of rows in the section.
   // ---- số lượng tùy số bộ tập
   if( soBoTap == 1 )
      return 8;
   if( soBoTap == 2 )
      return 13;
   if( soBoTap == 3 ) {
      if( section == 0 ) {
         return 9;
      }
      else if( section == 1 ) {
         return 11;
      }
      else {
         return 5;
      }

   }
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
   // ---- màu nền màn bảng
   [tableView setBackgroundColor:[UIColor colorWithRed:0.1f green:0.1f blue:0.1f alpha:1.0f]];

    static NSString *CellIdentifier = @"BàiHọc";
    TeBaoDanhSachBaiHoc *teBao = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
   // ---- số bài học
   NSInteger _soBaiHoc = [indexPath row] + 1;
   NSInteger phan = [indexPath section];
   
   // ==== ảnh
   NSString *tenAnh = [NSString stringWithFormat:@"ภาพ %d-%02d", soBoTap, _soBaiHoc];
   if( tenAnh ) {
      NSString *duongDan = [[NSBundle mainBundle] pathForResource:tenAnh ofType:@"jpg"];
      UIImage *anhTebao = [[UIImage alloc] initWithContentsOfFile:duongDan];
      [[teBao anh] setImage:anhTebao];
   }
   
   // ==== văn bản
   // ---- lấy tên bài học
   NSString *tenBaiHoc = NULL;
   
   if( soBoTap == 1 )
      tenBaiHoc = [QuanLyDanhSachBaiHoc layTenBoTap1_baiHoc:_soBaiHoc];
   else if( soBoTap == 2 )
      tenBaiHoc = [QuanLyDanhSachBaiHoc layTenBoTap2_baiHoc:_soBaiHoc];
   else if( soBoTap == 3 )
      tenBaiHoc = [QuanLyDanhSachBaiHoc layTenBoTap3_baiHoc:_soBaiHoc vaPhan:phan];
   else if( soBoTap == 6 )
      tenBaiHoc = [QuanLyDanhSachBaiHoc layTenBoTap6_baiHoc:_soBaiHoc];
   
   // ---- đặt nhẵn trong tế bào
   [[teBao vanBan] setText:tenBaiHoc];
   [[teBao vanBan] setTextColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f]];
    
    return teBao;
}

#pragma mark ---- Lấy Tên Cho Bài Học
+ (NSString *)layTenBoTap1_baiHoc:(unsigned char)_soBaiHoc; {

   NSString *tenBaiHoc = NULL;

   if( _soBaiHoc == 1 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๑ ท่าเทพพนม", @"Tên Bài Học 1-1" )];
   }
   else if( _soBaiHoc == 2 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๒ ก้มกราบ", @"Tên Bài Học 1-2" )];
   }
   else if( _soBaiHoc == 3 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๓ ท่าถวายบังคม", @"Tên Bài Học 1-3" )];
   }
   else if( _soBaiHoc == 4 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๔ ท่าปฐม", @"Tên Bài Học 1-4" )];
   }
   else if( _soBaiHoc == 5 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๕ ท่าพรหม", @"Tên Bài Học 1-5" )];
   }
   else if( _soBaiHoc == 6 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๖ เทพนิมิตร", @"Tên Bài Học 1-6" )];
   }
   else if( _soBaiHoc == 7 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๗ คุมเชิงครู", @"Tên Bài Học 1-7" )];
   }
   else if( _soBaiHoc == 8 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๑-๘ ย่างสามขุม", @"Tên Bài Học 1-8" )];
   }

   return tenBaiHoc;
}

+ (NSString *)layTenBoTap2_baiHoc:(unsigned char)_soBaiHoc; {
   
   NSString *tenBaiHoc = NULL;
   
   if( _soBaiHoc == 1 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๑ หมัดตรงชกนำ", @"Tên Bài Học 2-1" )];
   }
   else if( _soBaiHoc == 2 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๒ หมัดตรงชกตาม", @"Tên Bài Học 2-2" )];
   }
   else if( _soBaiHoc == 3 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๓ หมัดเหวี่ยง", @"Tên Bài Học 2-3" )];
   }
   else if( _soBaiHoc == 4 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๔ หมัดเหวี่ยงสั้น", @"Tên Bài Học 2-4" )];
   }
   else if( _soBaiHoc == 5 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๕ หมัดเหวี่ยงยาว", @"Tên Bài Học 2-5" )];
   }
   else if( _soBaiHoc == 6 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๖ หมัดเหวี่ยงกลับ", @"Tên Bài Học 2-6" )];
   }
   else if( _soBaiHoc == 7 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๗ หมัดเสย", @"Tên Bài Học 2-7" )];
   }
   else if( _soBaiHoc == 8 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๘ หมัดโขก", @"Tên Bài Học 2-8" )];
   }
   else if( _soBaiHoc == 9 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๙ ถอยสุดระยะ", @"Tên Bài Học 2-9" )];
   }
   else if( _soBaiHoc == 10 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๑๐ ผงะ", @"Tên Bài Học 2-10" )];
   }
   else if( _soBaiHoc == 11 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๑๑ ปะทะด้วยแขน", @"Tên Bài Học 2-11" )];
   }
   else if( _soBaiHoc == 12 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๑๒ ปัด", @"Tên Bài Học 2-12" )];
   }
   else if( _soBaiHoc == 13 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๒-๑๓ ชักหลบ", @"Tên Bài Học 2-13" )];
   }
   
   return tenBaiHoc;
}

+ (NSString *)layTenBoTap3_baiHoc:(unsigned char)_soBaiHoc vaPhan:(NSInteger)_phan; {
   
   NSString *tenBaiHoc = NULL;

   if( _phan == 0 ) {
      if( _soBaiHoc == 1 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑ ถีบตรง", @"Tên Bài Học 3-1" )];
      }
      else if( _soBaiHoc == 2 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒ ถีบเหน็บ", @"Tên Bài Học 3-2" )];
      }
      else if( _soBaiHoc == 3 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๓ ถีบเซาะ", @"Tên Bài Học 3-3" )];
      }
      else if( _soBaiHoc == 4 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๔ ถีบจิก", @"Tên Bài Học 3-4" )];
      }
      else if( _soBaiHoc == 5 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๕ ถีบทิ้ง", @"Tên Bài Học 3-5" )];
      }
      else if( _soBaiHoc == 6 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๖ ถีบข้าง", @"Tên Bài Học 3-6" )];
      }
      else if( _soBaiHoc == 7 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๗ ถีบตบ", @"Tên Bài Học 3-7" )];
      }
      else if( _soBaiHoc == 8 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๘ ถีบกลับหลัง", @"Tên Bài Học 3-8" )];
      }
      else if( _soBaiHoc == 9 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๙ กระโดดถีบ", @"Tên Bài Học 3-9" )];
      }
   }
   else if( _phan == 1 ) { // đá
      if( _soBaiHoc == 1 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๐ เตะตรง", @"Tên Bài Học 3-10" )];
      }
      else if( _soBaiHoc == 2 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๑ เตะเฉียง", @"Tên Bài Học 3-11" )];
      }
      else if( _soBaiHoc == 3 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๒ เตะตัดบน", @"Tên Bài Học 3-12" )];
      }
      else if( _soBaiHoc == 4 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๓ เตะตัดกลาง", @"Tên Bài Học 3-13" )];
      }
      else if( _soBaiHoc == 5 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๔ เตะตัดล่าง", @"Tên Bài Học 3-14" )];
      }
      else if( _soBaiHoc == 6 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๕ จระเข้ฟาดหาง (เตะเหวี่ยงหลัง/เตะกลับกลัง)", @"Tên Bài Học 3-15" )];
      }
      else if( _soBaiHoc == 7 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๖ กระโดดเตะ", @"Tên Bài Học 3-16" )];
      }
      else if( _soBaiHoc == 8 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๗ เตะครึ่งแข้ง ครึ่งเข่า", @"Tên Bài Học 3-17" )];
      }
      else if( _soBaiHoc == 9 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๘ เตะตวัด", @"Tên Bài Học 3-18" )];
      }
      else if( _soBaiHoc == 10 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๑๙ ตีลังกาเตะ", @"Tên Bài Học 3-19" )];
      }
      else if( _soBaiHoc == 11 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๐ เยียบเตะ", @"Tên Bài Học 3-20" )];
      }
   }
   else {  // thụt
      if( _soBaiHoc == 1 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๑ ถอยสุดระยะกันเตะ, ถอยสุดระยะกันถีบ", @"Tên Bài Học 3-21" )];
      }
      else if( _soBaiHoc == 2 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๒ จับกันเตะ, จับกันถีบ", @"Tên Bài Học 3-22" )];
      }
      else if( _soBaiHoc == 3 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๓ ปัดกันเตะ, ปัดกันถีบ", @"Tên Bài Học 3-23" )];
      }
      else if( _soBaiHoc == 4 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๔ ชิงถีบกันเตะ, ชิงถีบกันถีบ", @"Tên Bài Học 3-24" )];
      }
      else if( _soBaiHoc == 5 ) {
         tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๓-๒๕ โยกหลบกันเตะ, โยกหลบกันถีบ", @"Tên Bài Học 3-25" )];
      }
   }

   return tenBaiHoc;
}

+ (NSString *)layTenBoTap6_baiHoc:(unsigned char)_soBaiHoc; {
   
   NSString *tenBaiHoc = NULL;
   
   if( _soBaiHoc == 1 ) {
      tenBaiHoc = [NSString stringWithString:NSLocalizedString(@"๕-๑ Big Buck Bunny", @"Tên Bài Học 5-1" )];
   }
   
   return tenBaiHoc;
}

+ (NSString *)layTenBoTap5_baiHoc:(unsigned char)_soBaiHoc; {
   
   NSString *tenBaiHoc = NULL;
   
   
   return tenBaiHoc;
}

#pragma mark ---- Đổi Màu Nền Tế Bào
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell
forRowAtIndexPath:(NSIndexPath *)indexPath; {
   
   // ==== màu
   cell.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:1.0f];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
   
   NSString *tenPhan = NULL;
   if( soBoTap == 3 ) {
      if( section == 1 )
         tenPhan = @"เตะ";
      else if( section == 2 ) {
         tenPhan = @"ต่อย";
      }
   }

   return tenPhan;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

   return 88; // đơn vị màn iOS
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
   
   // ---- cho quản lý màn video biết chiếu bài học nào
   NSIndexPath *chiSoHang = [self.tableView indexPathForSelectedRow];
   soBaiHoc = [chiSoHang row] + 1;
   
   [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤ChiếuVideo" object:self];
//   [quanLyManVideo chieuVideoChoBoTap:soBoTap vaSoBaiHoc:soBaiHoc];
}

- (void)laySoBoTap:(NSNotification *)loiBao; {
   
   QuanLyBoTap *quanLyBoTap = [loiBao object];
   soBoTap = [quanLyBoTap soBoTap];
}

/*
#pragma mark - Storyboard
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender; {
   
   NSLog( @"%@", [segue identifier] );
   if( [[segue identifier] isEqualToString:@"MànChiếuVideo" ] ) {
      
      // ----- lấy quản lý màn video
      QuanLyManVideo *quanLyManVideo = [segue destinationViewController];
      
      // ---- cho quản lý màn video biết chiếu bài học nào
      NSIndexPath *chiSoHang = [self.tableView indexPathForSelectedRow];
      NSInteger soBaiHoc = [chiSoHang row] + 1;
   
      [quanLyManVideo setSoBoTap:soBoTap];
      [quanLyManVideo setSoBaiHoc:soBaiHoc];
   }
}
*/
@synthesize soBoTap;
@synthesize soBaiHoc;

@end

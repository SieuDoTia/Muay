//
//  QuanLyManChieuVideoVaBaiHoc.h
//  Muay
//
//  Created by 小小 on 21/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>
@class QuanLyManVideo;
@class QuanLyDanhSachBaiHoc;


@interface QuanLyManChieuVideoVaBaiHoc : UIViewController {
   
   QuanLyManVideo *quanLyManVideo;
   QuanLyDanhSachBaiHoc *quanLyDanhSachBaiHoc;
}

@end

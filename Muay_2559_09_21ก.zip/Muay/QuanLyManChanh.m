//
//  QuanLyManChanh.m
//  Muay
//
//  Created by 小小 on 10/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "QuanLyManChanh.h"
#import "QuanLyDanhSachBaiHoc.h"
#import "TeBaoManChanh.h"

@interface QuanLyManChanh ()

@end

@implementation QuanLyManChanh

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
   // ---- màu nền màn bảng
   [tableView setBackgroundColor:[UIColor colorWithRed:0.1f green:0.1f blue:0.1f alpha:1.0f]];
   
//   NSLog( @"QLManChanh %d", [indexPath row] );

    static NSString *CellIdentifier = @"BộTập";
    TeBaoManChanh *teBao = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
   // ---- số bài học
   NSInteger soBoTap = [indexPath row] + 1;
   
   // ==== ảnh
   NSString *tenAnh = [NSString stringWithFormat:@"ภาพ %d",  soBoTap];
   if( tenAnh ) {
      NSString *duongDan = [[NSBundle mainBundle] pathForResource:tenAnh ofType:@"png"];
      UIImage *anhTebao = [[UIImage alloc] initWithContentsOfFile:duongDan];
      [[teBao anh] setImage:anhTebao];
   }
   
   // ==== văn bản
   // ---- lấy tên bộ tập
   NSString *tenBoTap = [QuanLyManChanh layTenBoTapChoSoBoTap:soBoTap];

   // ---- đặt nhẵn tế bào
   [[teBao vanBan] setText:tenBoTap];
   [[teBao vanBan] setTextColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f]];
    
    return teBao;
}


+ (NSString *)layTenBoTapChoSoBoTap:(NSInteger)_soBotTap; {
   
   NSString *tenBoTap = NULL;
   
   if( _soBotTap == 1 ) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๑  ไว้ครู", @"Tên bộ tập 1" )];
   }
   else if( _soBotTap == 2) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๒  การใช้หมัด", @"Tên bộ tập 2" )];
   }
   else if( _soBotTap == 3) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๓  การใช้เท้า", @"Tên bộ tập 3" )];
   }
   else if( _soBotTap == 4) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๔  ", @"Tên bộ tập 4" )];
   }
   else if( _soBotTap == 5) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๕  ", @"Tên bộ tập 5" )];
   }
   else if( _soBotTap == 6) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๖  ", @"Tên bộ tập 6" )];
   }
   else if( _soBotTap == 7) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๗  ", @"Tên bộ tập 7" )];
   }
   else if( _soBotTap == 8) {
      tenBoTap = [NSString stringWithString:NSLocalizedString(@"ขั้นที่ ๘  ", @"Tên bộ tập 8" )];
   }
   
   return tenBoTap;
}

#pragma mark ---- Đổi Màu Nền Tế Bào
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell
forRowAtIndexPath:(NSIndexPath *)indexPath; {
   
   // ==== màu
   cell.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:1.0f];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath; {
   
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}


#pragma mark - Storyboard
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender; {
   
   if( [[segue identifier] isEqualToString:@"DanhSáchBàiHọc" ] ) {

      // ---- lấy quản lý danh sách bài học 
      QuanLyDanhSachBaiHoc *quanLyDanhSachBaiHoc = [segue destinationViewController];

      // ----- cho quản lý danh sách bài học biết chiếu bộ nào
      NSIndexPath *soBoTap = [self.tableView indexPathForSelectedRow];
      [quanLyDanhSachBaiHoc setSoBoTap:[soBoTap row] + 1];

   }
}



@end

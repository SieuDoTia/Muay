//
//  QuanLyBoTap.m
//  Muay
//
//  Created by 小小 on 17/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "QuanLyBoTap.h"
#import "TeBaoSuuTapManChanh.h"
#import "QuanLyDanhSachBaiHoc.h"


@interface QuanLyBoTap () {
   
//   NSMutableArray *mangAnhSuuTap;
}

@end

@implementation QuanLyBoTap

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning {

   [super didReceiveMemoryWarning];
   // Dispose of any resources that can be recreated.
}


- (void)viewDidLoad {

    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView; {
   
   return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section; {
   
   return 6;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath; {
   
   TeBaoSuuTapManChanh *teBao = [collectionView dequeueReusableCellWithReuseIdentifier:@"Tế Bào ขั้น" forIndexPath:indexPath];
   
   NSInteger soAnh = [indexPath row] + 1;
   NSString *tenAnh = [NSString stringWithFormat:@"ขั้น %02d", soAnh ];
   NSLog( @"soAnh %d  tenAnh %@", soAnh, tenAnh );
   
   // ---- đặt ảnh
   if( tenAnh ) {
      NSString *duongDan = [[NSBundle mainBundle] pathForResource:tenAnh ofType:@"jpg"];
      UIImage *anhTebao = [[UIImage alloc] initWithContentsOfFile:duongDan];
      [[teBao anh] setImage:anhTebao];
   }
   
   // ---- đặt văn bản
   NSString *tenBoTap = [NSString stringWithFormat:@"ขั้น %02d", soAnh ];
   if( tenBoTap ) {
      [[teBao vanBan] setText:tenBoTap];
      [[teBao vanBan] setTextColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f]];
   }

   return teBao;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath; {
   
   soBoTap = [indexPath item] + 1;
   NSLog( @"soBaiHoc %d", soBoTap );
   [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤CóSốBộTập" object:self];
}


#pragma mark - Storyboard
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender; {
   
   if( [[segue identifier] isEqualToString:@"MànChiếuVideoVàBàiHọc" ] ) {
      
      // ---- lấy quản lý danh sách bài học
//      QuanLyDanhSachBaiHoc *quanLyDanhSachBaiHoc = [segue destinationViewController];
      
      // ----
   //   TeBaoSuuTapManChanh *teBao = [sender object];
      // ----- cho quản lý danh sách bài học biết chiếu bộ nào
//      NSIndexPath *soBoTap = [self.collectionView indexPathForCell:sender];
//      [quanLyDanhSachBaiHoc setSoBoTap:[soBoTap row] + 1];
   }
}

@synthesize soBoTap;

@end

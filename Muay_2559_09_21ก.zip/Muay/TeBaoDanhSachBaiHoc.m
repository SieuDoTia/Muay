//
//  TeBaoDanhSachBaiHoc.m
//  Muay
//
//  Created by 小小 on 10/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "TeBaoDanhSachBaiHoc.h"

@implementation TeBaoDanhSachBaiHoc

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


@synthesize anh;
@synthesize vanBan;

@end

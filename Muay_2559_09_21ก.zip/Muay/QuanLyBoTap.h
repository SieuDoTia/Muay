//
//  QuanLyBoTap.h
//  Muay
//
//  Created by 小小 on 17/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuanLyBoTap : UICollectionViewController {

   NSInteger soBoTap;
}

@property (readonly) NSInteger soBoTap;

@end

//
//  TeBaoSuuTapManChanh.m
//  Muay
//
//  Created by 小小 on 18/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "TeBaoSuuTapManChanh.h"

@implementation TeBaoSuuTapManChanh

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


/*- (UIImageView *)anh {
   if (!anh) {
      anh = [[UIImageView alloc] initWithFrame:self.contentView.bounds];
      [self.contentView addSubview:anh];
   }
   return anh;
}*/


//- (void)setAnh:(UIImageView *)anh; {
   
//}

// Here we remove all the custom stuff that we added to our subclassed cell
/*-(void)prepareForReuse; {
   [super prepareForReuse];
   
   [anh removeFromSuperview];
   [vanBan removeFromSuperview];
   anh = NULL;
   vanBan = NULL;
} */

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/



@synthesize anh;
@synthesize vanBan;

@end

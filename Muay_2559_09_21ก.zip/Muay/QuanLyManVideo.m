//
//  QuanLyManVideo.m
//  Muay
//
//  Created by 小小 on 7/9/2559.
//  Copyright (c) 2559 BE 星凤. All rights reserved.
//

#import "QuanLyManVideo.h"
#import "QuanLyDanhSachBaiHoc.h"

@interface QuanLyManVideo () {

}
@end

@implementation QuanLyManVideo


- (void)viewDidLoad {
    [super viewDidLoad];
   
	// Do any additional setup after loading the view, typically from a nib.
   [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(laySoBoTapVaBaiTap:) name:@"星凤ChiếuVideo" object:NULL];
}

- (void)chieuVideoChoBoTap:(NSInteger)soBoTap vaSoBaiHoc:(NSInteger)soBaiHoc; {
   
   // ---- lấy URL video
   NSURL *URL_dongVideo = NULL;
   
   if( soBoTap == 1 )
      URL_dongVideo = [QuanLyManVideo layURLVideoBoTap1_choSoBaiHoc:soBaiHoc];
   else if( soBoTap == 2 )
      URL_dongVideo = [QuanLyManVideo layURLVideoBoTap2_choSoBaiHoc:soBaiHoc];
   else if( soBoTap == 3 )
      URL_dongVideo = [QuanLyManVideo layURLVideoBoTap3_choSoBaiHoc:soBaiHoc];
   else if( soBoTap == 4 )
      URL_dongVideo = [QuanLyManVideo layURLVideoBoTap4_choSoBaiHoc:soBaiHoc];
   else if( soBoTap == 6 )
      URL_dongVideo = [QuanLyManVideo layURLVideoBoTap6_choSoBaiHoc:soBaiHoc];
   
   // ---- ho kiểm tra url video
   NSLog( @"url %@", [URL_dongVideo absoluteString] );
   
   if( URL_dongVideo ) {
      // ---- 'xin' vật thể mạng
      NSURLRequest *vatTheMangDangXin = [NSURLRequest requestWithURL:URL_dongVideo];
      // ---- tải vật thể mạng
      [(UIWebView *)self.view loadRequest:vatTheMangDangXin];
   }
   else {
      NSLog( @"QuanLyManVideo: videwDidLoad: Có vấn đề với URL video" );
   }
}

#pragma mark ---- URL Kết Nối Video
+ (NSURL *)layURLVideoBoTap1_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130070292"];
   }
   else if( _soBaiHoc == 2 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130070293"];
   }
   else if( _soBaiHoc == 3 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130070295"];
   }
   else if( _soBaiHoc == 4 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130072841"];
   }
   else if( _soBaiHoc == 5 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130072843"];
   }
   else if( _soBaiHoc == 6 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130072844"];
   }
   else if( _soBaiHoc == 7 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130072845"];
   }
   else if( _soBaiHoc == 8 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130072848"];
   }
   
   return urlVideo;
}

+ (NSURL *)layURLVideoBoTap2_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130167084"];
   }
   else if( _soBaiHoc == 2 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130167085"];
   }
   else if( _soBaiHoc == 3 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/134181883"];
   }
   else if( _soBaiHoc == 4 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130167086"];
   }
   else if( _soBaiHoc == 5 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130167088"];
   }
   else if( _soBaiHoc == 6 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130167089"];
   }
   else if( _soBaiHoc == 7 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130182794"];
   }
   else if( _soBaiHoc == 8 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130182793"];
   }
   else if( _soBaiHoc == 9 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131395231"];
   }
   else if( _soBaiHoc == 10 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131395697"];
   }
   else if( _soBaiHoc == 11 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131395698"];
   }
   else if( _soBaiHoc == 12 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131395699"];
   }
   else if( _soBaiHoc == 13 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131395700"];
   }
   
   return urlVideo;
}

+ (NSURL *)layURLVideoBoTap3_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132306708"];
   }
   else if( _soBaiHoc == 2 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136304292"];
   }
   else if( _soBaiHoc == 3 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136304293"];
   }
   else if( _soBaiHoc == 4 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132306711"];
   }
   else if( _soBaiHoc == 5 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132316577"];
   }
   else if( _soBaiHoc == 6 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132318594"];
   }
   else if( _soBaiHoc == 7 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132318595"];
   }
   else if( _soBaiHoc == 8 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132318596"];
   }
   else if( _soBaiHoc == 9 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/132318597"];
   }
   // ---- đá
   else if( _soBaiHoc == 10 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130284867"];
   }
   else if( _soBaiHoc == 11 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130284868"];
   }
   else if( _soBaiHoc == 12 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130284869"];
   }
   else if( _soBaiHoc == 13 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130284871"];
   }
   else if( _soBaiHoc == 14 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130284872"];
   }
   else if( _soBaiHoc == 15 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130288474"];
   }
   else if( _soBaiHoc == 16 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130288475"];
   }
   else if( _soBaiHoc == 17 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130288477"];
   }
   else if( _soBaiHoc == 18 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130288478"];
   }
   else if( _soBaiHoc == 19 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130288479"];
   }
   else if( _soBaiHoc == 20 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130291103"];
   }
   // ---- thụt
   else if( _soBaiHoc == 21 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136304295"];
   }
   else if( _soBaiHoc == 22 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131396447"];
   }
   else if( _soBaiHoc == 23 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131396451"];
   }
   else if( _soBaiHoc == 24 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131396450"];
   }
   else if( _soBaiHoc == 25 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136304294"];
   }
   
   return urlVideo;
}

+ (NSURL *)layURLVideoBoTap4_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130402719"];
   }
   else if( _soBaiHoc == 2 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136309460"];
   }
   else if( _soBaiHoc == 3 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130402721"];
   }
   else if( _soBaiHoc == 4 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130402722"];
   }
   else if( _soBaiHoc == 5 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130402723"];
   }
   else if( _soBaiHoc == 6 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136311405"];
   }
   else if( _soBaiHoc == 7 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130408409"];
   }
   else if( _soBaiHoc == 8 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130408410"];
   }
   else if( _soBaiHoc == 9 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130508136"];
   }
   else if( _soBaiHoc == 10 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/130408413"];
   }
   else if( _soBaiHoc == 11 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131400101"];
   }
   else if( _soBaiHoc == 12 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131400100"];
   }
   else if( _soBaiHoc == 13 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/136311404"];
   }
   else if( _soBaiHoc == 14 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131400103"];
   }
   else if( _soBaiHoc == 15 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131397388"];
   }
   else if( _soBaiHoc == 16 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131397389"];
   }
   else if( _soBaiHoc == 17 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131397390"];
   }
   else if( _soBaiHoc == 18 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131397391"];
   }

   return urlVideo;
}

+ (NSURL *)layURLVideoBoTap5_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131501345"];
   }
   else if( _soBaiHoc == 2 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131614304"];
   }
   else if( _soBaiHoc == 3 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131501347"];
   }
   else if( _soBaiHoc == 4 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131507284"];
   }
   else if( _soBaiHoc == 5 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131501349"];
   }
   else if( _soBaiHoc == 6 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131506844"];
   }
   else if( _soBaiHoc == 7 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131515872"];
   }
   else if( _soBaiHoc == 8 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131620080"];
   }
   else if( _soBaiHoc == 9 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131515874"];
   }
   else if( _soBaiHoc == 10 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131620090"];
   }
   else if( _soBaiHoc == 11 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131614333"];
   }
   else if( _soBaiHoc == 12 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131751066"];
   }
   else if( _soBaiHoc == 13 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131751065"];
   }
   else if( _soBaiHoc == 14 ) {
      urlVideo = [NSURL URLWithString:@"https://player.vimeo.com/video/131751063"];
   }

   return urlVideo;
}

+ (NSURL *)layURLVideoBoTap6_choSoBaiHoc:(NSInteger)_soBaiHoc; {
   
   NSURL *urlVideo = NULL;
   
   if( _soBaiHoc == 1 ) {
      urlVideo = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/u/7303267/website/m3u8/index.m3u8"];
   }

   return urlVideo;
}

#pragma mark ---- 
- (void)laySoBoTapVaBaiTap:(NSNotification *)loiBao; {
   
   QuanLyDanhSachBaiHoc *quanLyDanhSachBaiHoc = [loiBao object];
   
   [self chieuVideoChoBoTap:[quanLyDanhSachBaiHoc soBoTap] vaSoBaiHoc:[quanLyDanhSachBaiHoc soBaiHoc]];
}

- (void)didReceiveMemoryWarning; {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//@synthesize soBoTap;
//@synthesize soBaiHoc;


@end
